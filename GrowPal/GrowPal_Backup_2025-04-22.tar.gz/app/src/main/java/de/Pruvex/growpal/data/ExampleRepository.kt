package de.Pruvex.growpal.data

// Beispiel-Repository für GrowPal
class ExampleRepository {
    fun getWelcomeMessage(): String = "GrowPal ist bereit."
}
